<?php
// require_once('required/function.php');
//   extract($_POST);
// echo "<pre>";

// add_column('student', 'my_token'); 

// $findstudent = get_data('student',$_GET['adm'], null,'student_admission')['data'];

// //echo  $findstudent['id'];
// //print_r($findstudent);

// print_r(duesmonthcount($findstudent['id']));
// echo finaldues($findstudent['id']);



// echo update_payment(435, 1050);
