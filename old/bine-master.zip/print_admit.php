<?php
require_once("required/op_lib.php");
$_POST = post_clean($_POST);
extract($_POST);
if (isset($student_admission) and $student_admission != '') {
	$student_admission = str_replace(' ', '', $_POST['student_admission']);
	$student_list = explode(",", $student_admission);
} else {

	if ($student_roll <> '') {
		$sql = " select * from student where student_class ='$student_class' and student_section ='$student_section' and finance_type='NORMAL' and status ='ACTIVE' and student_roll in ($student_roll)";
	} else {
		$sql = "select * from student where student_class ='$student_class'  and student_section ='$student_section'";
	}
	$res = direct_sql($sql)['data'];
	//$res = mysqli_query($con,xss_clean($sql));
	//$res = mysqli_query($con,$sql);
	//while($row =mysqli_fetch_assoc($res))
	foreach ($res as $row) {
		$student_list[] = $row['id'];
	}
}
?>


<style>
	/*body{*/
	/*	color:#000;*/
	/*	padding:0px;*/
	/*	margin:0px;*/
	/*}*/

	/*td{font-size:16px;padding:10px;font-family:calibri,arial;font-weight:600;}*/

	/*.idcard{width:750px; height:550px; background:url('assets/img/idcardpng') no-repeat; text-align:center; float:left; margin:6px; page-break-after:always;position:relative;}*/
	/*.photo{position:absolute;margin:auto;top:10px;left:10px;margin-right:50px;z-index:0;border:solid 0px #ddd;border-radius:100%;}*/
	/*.qr{position:absolute;width:55px; height:55px;margin:auto;top:255px;right:18px;z-index:0;border:solid 0px #000;border-radius:5px;}*/

	@media print {
		#printbtn {
			display: none;
		}

		@page {
			size: portrait
		}

		#DivIdToPrint {
			page-break-inside: avoid;
			margin: 10px;
		}
	}
</style>


<?php foreach ($student_list as $sid) {

	// $student = get_data("student",$sid)['data'];
	// extract($student);
?>
	<table border='1' class='idcard mt-4' cellpadding='3' rules='all' width='750px' id='DivIdToPrint'>

		<tr height='85px'>

			<td align='center' class='header'>
				<img src='images/logo.png' height='120px' align='left'>
				<span style='font-size:36px;font-weight:800;font-family:calibri;text-transform:uppercase;color:maroon;'> <?php echo $full_name; ?> </span><br>
				<b>(Affiliated to CBSE, New Delhi upto 10+2) <br>
					<b>Affiliation No. : <?php echo $aff_no; ?> School No. : <?php echo $school_code; ?></b><br>
					<?php echo $inst_address1; ?>, <?php echo $inst_address2; ?> <br>
					Contact No.: <?php echo $inst_contact; ?><br>
					Email : <?php echo $inst_email; ?> | Website : <?php echo $inst_url; ?>
			</td>

		</tr>
		<tr height='30px' bgcolor='#d5d5d5'>
			<td>
				<center><b> <?php
							$student_class = get_data("student", $sid, 'student_class')['data'];
							echo $exam_name = get_all('admit_card', '*', array('student_class' => $student_class))['data'][0]['exam_name'];
							?> (HALL TICKET)</b> </center>
			</td>
		</tr>
		<tr>
			<td style='text-align:left;padding:10px;vertical-align:top;'>


				<table class='table' width='100%' cellpadding='5'>
					<tr>
						<td>Admission No.: </td>
						<td><?php echo get_data("student", $sid, 'student_admission')['data']; ?> </td>
						<td rowspan='6'>
							<img src='upload/<?php echo get_data("student", $sid, 'student_photo'); ?>' align='right' alt='Student Photo Here' style='border : solid 1px #ddd' width='150px' height='180px' />
						</td>
					</tr>

					<tr>
						<td>Class & Section : </td>
						<td><?php echo get_data("student", $sid, 'student_class')['data']; ?> <?php echo get_data("student", $sid, 'student_section')['data']; ?> </td>
					</tr>

					<tr>
						<td>Roll No. : </td>
						<td><?php echo get_data("student", $sid, 'student_roll')['data']; ?> </td>
					</tr>

					<tr>
						<td>Name : </td>
						<td><?php echo get_data("student", $sid, 'student_name')['data']; ?> </td>
					</tr>

					<tr>
						<td>Father's Name :</td>
						<td> <?php echo get_data("student", $sid, 'student_father')['data']; ?> </td>
					</tr>

					<tr>
						<td> Address : </td>
						<td><?php echo get_data("student", $sid, 'student_address1')['data']; ?> </td>
					</tr>

					<tr class='bg-dark text-light text-center'>
						<th colspan='3'> Exam Time Table for <?php echo $student_class; ?> </th>
					</tr>
					<tr align='center'>
						<th> Date </th>
						<th> Subject </th>
						<th> Timing </th>
					</tr>

					<?php

					$sql = "select * from admit_card where student_class ='$student_class' order by exam_date ";
					$routine = direct_sql($sql)['data'];

					//  $routine = get_all('admit_card', '*', array('student_class'=> $student_class),'')['data'];


					foreach ($routine as $row) {
						echo "<tr align='center'>";
						echo "<td>" . date('d-M-Y', strtotime($row['exam_date'])) . "</td>";
						echo "<td>" . $row['subject'] . "</td>";
						echo "<td>" . $row['timing'] . "</td>";
						echo "</tr>";
					}
					?>
				</table>

			</td>
		</tr>
		<tr>
			<td valign='bottom'>

				<div style='float:right;bottom:10px;'>
					<img src='images/sign.jpg' align='right' height='65px'> <br>
					Signature of Principal
				</div>
			</td>
		</tr>
		<tr>
			<td>
				<b> Instructions :</b>
				<ul>
					<li>
						Candidates should note that an authenticated Admit Card is an important document without which the candidate will not be permitted to appear for further selection
					</li>
					<li>Cell phones, calculators, watch calculators, alarm clocks, digital watches with built in calculators/ memory or any electronic or smart devices are not be allowed in the exam hall.</li>
					<li>
						Candidates will not be allowed to leave the test hall till the test is completed. After submission of the test, candidate will not be allowed to re-enter the test hall.
					</li>
				</ul>
			</td>
		</tr>
	</table>

<?php } ?>