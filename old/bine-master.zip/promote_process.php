<?php
require_once('required/header.php');
require_once('required/menu.php');
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1> Trip Management</h1>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="breadcrumb-item"><a href="#transport">Transport</a></li>
      <li class="breadcrumb-item active">Trip Management</li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-12">
        <?php
        $new_db = 'andpubli_pub2122';
        $new_session = '2021-2022';
        $created_at = date('Y-m-d h:i:s');
        $all_list = post_clean($_POST);
        foreach ($all_list  as $list) {
          $data = decode(xss_clean($list));
          extract($data);
          if (isset($promote_class)) {
            /* ======= COPY STUDENT DATA FROM OLD DATABASE TO NEW DB =============*/
            $sql1 = "insert into $new_db.student select * from student where id ='$student_id' and status ='ACTIVE'";
            $res1 = direct_sql($sql1, 'set');
            //     echo "Result 1";
            //     print_r($res1);

            // /* ======= IF COPY SUCCESS UPDATE REQUIRED INFORMATION TO NEW DB ======*/
            // if($res2['status']=='success')
            // {
            //     $udata = array('student_class'=>$promote_class, 'base_dues'=>$final_dues,'student_session'=>$student_session,'created_at'=>$created_at);
            $res2  = update_data($new_db . '.student', $udata, $student_id);
            //     echo "Result 3";
            //     print_r($res2);
            // }

            // /*=====UPDATE PREVIOUS ALL DUES TO STUDENT FEE TABEL OF NEW DB ======*/
            // if($res2['status']=='success')
            // {
            $res3 = insert_data($new_db . '.student_fee', array('student_id' => $student_id, 'student_admission' => $student_admission, 'current_dues' => $final_dues));
            //     echo "Result 3";
            //     print_r($res3);
            // }

            // if($res3['status']=='success')
            // {
            /* ======= MARK THE STUDENT AS PROMOTED IN OLD DATABSE ======*/
            $res4 = update_data('student', array('status' => 'PROMOTED'), $student_admission, 'student_admission');
            //     echo "Result 4";
            //     print_r($res4);
            // }
          }
        }
        ?>
      </div>

    </div>
  </section>
</div>
<?php require_once('required/footer2.php'); ?>