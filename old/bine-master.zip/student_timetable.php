<?php require_once("required/header.php"); ?>
<?php require_once("required/menu.php"); ?>

<?php require_once("required/footer2.php"); ?>