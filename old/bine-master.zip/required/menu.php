<aside class="main-sidebar">
	<section class="sidebar">
		<div class="user-panel">
			<div class="image float-left">
				<img src="images/user2-160x160.jpg" class="rounded-circle" alt="User Image">
			</div>
			<div class="info float-left">
				<p>Welcome <?php echo $user_name; ?></p> <a href="#"><i
						class="fa fa-circle text-success"></i><?php echo $user_type; ?></a>
			</div>
			<form action="collect_fee" method="get" class="sidebar-form">
				<input name="student_class" type='hidden'>
				<input name="search_by" type='hidden' value='student_name'>
				<div class="input-group">
					<input type="text" name="search_text" class="form-control" id='search_text'
						placeholder="Student Name"> <span class="input-group-btn"> <button type="submit" name="search"
							id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i> </button> </span>
				</div>
			</form>
		</div>
		<ul class="sidebar-menu" data-widget="tree" id='nav'>
			<li>
				<a href="dashboard"> <i class="fa fa-dashboard"></i> Dashboard</a>
			</li>
			<li class="treeview">
				<a href="#"> <i class="fa fa-user-circle"></i> <span>Members</span> <span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i> </span>
				</a>
				<ul class="treeview-menu">
					<li><a href="add_member">Add Member</a></li>
					<li><a href="manage_member">Manage Member</a></li>
				</ul>
			</li>
			<li class="treeview">
				<a href="#"> <i class="fa fa-user-circle"></i> <span>Deposits</span> <span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i> </span>
				</a>
				<ul class="treeview-menu">
					<li><a href="add_member">Fixed Deposit (FD)</a></li>
					<li><a href="manage_member">Recurring Deposit (RD)</a></li>
					<li><a href="manage_member">Deposit Report</a></li>
				</ul>
			</li>

			<?php if ($user_type == 'DBA' or $user_type == 'Admin') { ?>
				<li class="treeview">
					<a href="#"> <i class="fa fa-info-circle"></i> <span>Enquiry Management</span> <span
							class="pull-right-container"> <i class="fa fa-angle-left pull-right"></i> </span>
					</a>
					<ul class="treeview-menu">
						<li><a href="add_enquiry">Add Enquiry</a></li>
						<li><a href="manage_enquiry">Manage Enquiry</a></li>
						<li><a href="form_collection">Form Sale Report </a></li>
					</ul>
				</li>
			<?php } ?>
			<?php if ($user_type == "DBA" or $user_type == 'Admin') { ?>
				<li class="treeview">
					<a href="#"> <i class="fa fa-edit"></i> <span>Attendance Managmnt</span> <span
							class="pull-right-container"> <i class="fa fa-angle-left pull-right"></i> </span>
					</a>
					<ul class="treeview-menu">
						<li><a href="employee_attendance">Employee Attendance</a></li>
						<li><a href="student_att">Student Attendance</a></li>
					</ul>
				</li>
			<?php } ?>
			<?php if ($user_type == "DBA" or $user_type == 'Admin') { ?>
				<li class="treeview">
					<a href="#"> <i class="fa fa-user-circle"></i> <span>Employee Managment</span> <span
							class="pull-right-container"> <i class="fa fa-angle-left pull-right"></i> </span>
					</a>
					<ul class="treeview-menu">
						<li><a href="manage_employee">Manage Employee</a></li>
						<li><a href="manage_driver">Manage Driver</a></li>
						<li><a href="manage_salary">Manage Salary</a></li>
						<li><a href="emp_att_report">Attendance Report</a></li>
					</ul>
				</li>
			<?php } ?>
			<?php if ($user_type == 'DBA' or $user_type == 'Admin' or $user_type == 'Account') { ?>
				<li class="treeview">
					<a href="#"> <i class="fa fa-male"></i> <span>Student Management</span> <span
							class="pull-right-container"> <i class="fa fa-angle-left pull-right"></i> </span>
					</a>
					<ul class="treeview-menu">
						<li><a href="add_student">Add Student</a></li>
						<li><a href="manage_student">Manage Student </a></li>
						<li><a href="student_status">Student Report</a></li>
						<li><a href="manage_homework">Manage Homework</a></li>
						<li><a href="student_datewise_report">Datewise Report</a></li>
						<li><a href="student_monthwise_att_report">Monthwise Report</a></li>
						<li><a href="att_summary">Attendance Summary</a></li>
					</ul>
				</li>
			<?php } ?>
			<?php if ($user_type == 'DBA' or $user_type == 'Admin') { ?>
				<li class="treeview">
					<a href="#"> <i class="fa fa-list"></i> <span>Timetable Managment</span> <span
							class="pull-right-container"> <i class="fa fa-angle-left pull-right"></i> </span>
					</a>
					<ul class="treeview-menu">
						<li><a href="create_timeslot">Create TimeSlot</a></li>
						<li><a href="create_timetable">Create TimeTable</a></li>
						<li><a href="manage_timetable">Manage TimeTable</a></li>
						<li><a href="classroom_timetable">Classroom TimeTable</a></li>
						<li><a href="faculty_timetable">Faculty TimeTable</a></li>
						<li><a href="student_timetable">Student TimeTable</a></li>
						<!-- <li><a href="student_status">Student Report</a></li> -->
					</ul>
				</li>
			<?php } ?>
			<?php if ($user_type == 'DBA' or $user_type == 'Admin' or $user_type == 'Account') { ?>
				<li class="treeview">
					<a href="#"> <i class="fa fa-list"></i> <span>Lesson Plan</span> <span class="pull-right-container"> <i
								class="fa fa-angle-left pull-right"></i> </span>
					</a>
					<ul class="treeview-menu">
						<li><a href="create_lesson">Create Lesson</a></li>
						<li><a href="manage_lesson">Manage Lesson</a></li>
						<li><a href="classroomwise_topic_status">Classroom-wise Topic</a></li>
						<li><a href="subjectwise_topic_status">Subject-wise Topic</a></li>
						<li><a href="manage_question">Manage Question</a></li>
					</ul>
				</li>
			<?php } ?>
			<?php if ($user_type == 'Account' or $user_type == 'Admin') { ?>
				<li class="treeview">
					<a href="#"> <i class="fa fa-shopping-cart"></i> <span>Inventory Management</span> <span
							class="pull-right-container"> <i class="fa fa-angle-left pull-right"></i> </span>
					</a>
					<ul class="treeview-menu">
						<li><a href="item_cat">Item Category</a></li>
						<li> <a href="manage_item">Manage Item</a></li>
						<li> <a href="manage_vendor">Manage Vendor</a></li>
						<li> <a href="manage_distribute_item">Distribute Item</a></li>
						<li> <a href="item_details">Item Stock Report</a></li>
					</ul>
				</li>
				<li class="treeview">
					<a href="#"> <i class="fa fa-inr"></i> <span>Fee Management</span> <span class="pull-right-container">
							<i class="fa fa-angle-left pull-right"></i> </span>
					</a>
					<ul class="treeview-menu">
						<li> <a href="collect_fee.php" accesskey='c'>
								<akey>C</akey>ollect Fee
							</a>
						</li>
						<li> <a href="collection_report.php" accesskey='s'>
								<akey>S</akey>how Collection
							</a>
						</li>
						<li> <a href="generate_demand.php" accesskey='d'>
								<akey>D</akey>emand Print
							</a>
						</li>
						<li> <a href="route_demand.php" accesskey='r'>
								<akey>R</akey>oute wise Demand
							</a>
						</li>
						<li> <a href="class_wise_ledger.php"> Class Wise Ledger</a>
						</li>
					</ul>
				</li>

				<li class="treeview">
					<a href="#"> <i class="fa fa-truck"></i> <span>Transport Managment</span> <span
							class="pull-right-container"> <i class="fa fa-angle-left pull-right"></i> </span>
					</a>
					<ul class="treeview-menu">
						<li> <a href="add_vehicle.php" accesskey='v'>
								Add <akey>V</akey>ehicle
								<span class="badge badge-success">NEW</span>
							</a>
						</li>
						<li> <a href="add_area.php" accesskey='a'>
								<akey>A</akey>dd Area
							</a>
						</li>
						<li><a href="exp_head.php">
								Add Expense
								<span class="badge badge-success">NEW</span>
							</a>
						</li>
						<li> <a href="add_trip.php" accesskey='T'> Add <akey>T</akey>rip </a>
						</li>
						<li> <a href="area_wise_report.php"> Area Wise Report </a>
						</li>
						<li> <a href="vehicle_report.php"> Vehicle Report <span class="badge badge-success">NEW</span> </a>
						</li>
					</ul>
				</li>
			<?php } ?>
			<?php if ($user_type == 'DBA' or $user_type == 'Admin' or $user_type == 'Account') { ?>
				<li class="treeview">
					<a href="#"> <i class="fa fa-graduation-cap"></i> <span>Exam Management</span> <span
							class="pull-right-container"> <i class="fa fa-angle-left pull-right"></i> </span>
					</a>
					<ul class="treeview-menu">
						<li> <a href="admit_card">Admit Card </a>
						</li>
						<li> <a href="manage_admit_card"> View Admit Card </a>
						</li>
						<li> <a href="print_admit_card"> Print Admit Card </a>
						</li>
						<li> <a href="exam_routine">Print Exam Routine</a>
						</li>
						<li> <a href="marks_entry"> Marks Entry </a>
						</li>
						<li> <a href="marks_upload"> Bulk Marks Upload </a>
						</li>
						<li> <a href="consolidated_marks"> Consolidated Marks </a>
						</li>
						<li>
							<a href="generate_report_card"> Print Report Card</a>
						</li>
					</ul>
				</li>
			<?php } ?>
			<?php if ($user_type == 'Librarian' or $user_type == 'Admin') { ?>
				<li class="treeview">
					<a href="#"> <i class="fa fa-book"></i> <span>Library Managment </span> <span
							class="pull-right-container"> <i class="fa fa-angle-left pull-right"></i> </span>
					</a>
					<ul class="treeview-menu">
						<li> <a href="book_cat.php"> Book Category </a>
						</li>
						<li> <a href="book_pub.php"> Book Publisher </a>
						</li>
						<li> <a href="manage_book.php"> Manage Book </a>
						</li>
						<li> <a href="issue_book.php"> Issue A Book </a>
						</li>
						<li> <a href="book_return.php"> Return Book </a>
						</li>
						<li> <a href="return_report.php"> Return Report </a>
						</li>
					</ul>
				</li>
			<?php } ?>
			<?php if ($user_type == 'Account' or $user_type == 'Admin') { ?>
				<li class="treeview">
					<a href="#"> <i class="fa fa-inr"></i> <span>Accounts </span> <span class="pull-right-container"> <i
								class="fa fa-angle-left pull-right"></i> </span>
					</a>
					<ul class="treeview-menu">
						<li> <a href="acc_dash">Account Dashbord </a></li>
						<li> <a href="exp_head.php">Expense Head </a>
						</li>
						<li>
							<a href="manage_account.php"> Manage Transaction</a>
						</li>

						<li>
							<a href="date_wise_report.php"> Date Wise Report</a>
						</li>
						<?php if ($user_type == 'DBA' or $user_type == 'Admin') { ?>
							<li>
								<a href="head_wise_report.php"> Head Wise Report</a>
							</li>
						<?php } ?>
					</ul>
				</li>
			<?php } ?>
			<?php if ($user_type == 'DBA' or $user_type == 'Admin') { ?>
				<li class="treeview">
					<a href="#"> <i class="fa fa-globe"></i> <span>Extra </span> <span class="pull-right-container"> <i
								class="fa fa-angle-left pull-right"></i> </span>
					</a>
					<ul class="treeview-menu">
						<li> <a href="send_sms.php"> Send SMS </a>
						</li>
						<li> <a href="sms_template.php"> Send Template </a>
						</li>
						<li> <a href="generate_idcard.php"> Identity Card </a>
						</li>
						<li> <a href="create_certificate.php"> Create Certificate </a>
						</li>
						<li> <a href="employee_status.php"> Employee List</a>
						</li>
					</ul>
				</li>
			<?php } ?>
			<?php if ($user_type == 'Admin' or $user_type == 'Developer') { ?>
				<li class="treeview">
					<a href="#"> <i class="fa fa-cog"></i> <span>Settings</span> <span class="pull-right-container"> <i
								class="fa fa-angle-left pull-right"></i> </span>
					</a>
					<ul class="treeview-menu">
						<li> <a href="add_fee.php"> Create Fee </a>
						</li>
						<li> <a href="update_fee.php"> Set Fee Amount </a>
						</li>
						<li> <a href="subject_setting.php"> Manage Subject </a>
						</li>
						<li> <a href="add_user.php"> Manage User </a>
						</li>
						<li> <a href="bulk_import.php">Bulk Import </a>
						</li>
						<li>
							<a href="admin_txn.php"> Admin Transaction</a>
						</li>
						<li>
							<a href="admin_account.php"> Transaction Report</a>
						</li>
						<li> <a href="fee_test.php" accesskey='r'> <span class='badge badge-success'>R</span> Recheck </a>
						</li>
						<li>
							<?php // echo $current_session;
								if ($session_list[$db_name] != $current_session) { ?>

							<li> <a href="promote_student.php">Promote Student </a>
							</li>
						<?php } ?>
					</ul>
				</li>
			<?php } ?>
		</ul>
	</section>
	<div class="sidebar-footer">
		<a href="#" class="link" data-toggle="tooltip" title="" data-original-title="Settings" id='appinfo'><i
				class="fa fa-cog fa-spin"></i></a>
		<a href="support" class="link" data-toggle="tooltip" title="" data-original-title="Help & Support"><i
				class="fa fa-life-ring" aria-hidden="true"></i></i></a>
		<a href="#" class="link" data-toggle="tooltip" title="" onclick="logout()"><i class="fa fa-power-off"></i></a>
	</div>
</aside>