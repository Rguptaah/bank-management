<script>
    window.location = 'http://localhost/bine-master/login.php';
</script>