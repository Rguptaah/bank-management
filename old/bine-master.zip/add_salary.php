<?php require_once('required/header.php'); ?>
<?php require_once('required/menu.php');
$table_name = 'salary';
if (isset($_GET['link']) and $_GET['link'] != '') {
    $item = decode($_GET['link']);
    $id = $item['id'];
} else {
    $item = insert_row($table_name);
    $id = $item['id'];
}
if ($id != '') {
    $res = get_data($table_name, $id);
    if ($res['count'] > 0 and $res['status'] == 'success') {
        extract($res['data']);
    }
}
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>Salary Details</h1>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="breadcrumb-item"><a href="#">Employee Management</a></li>
            <li class="breadcrumb-item active">Add Salary</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">

        <!-- Basic Forms -->
        <div class="box box-default">
            <div class="box-header with-border">
                <h3 class="box-title">Add /Update Salary </h3>

                <div class="box-tools pull-right">
                    <button class="btn btn-success" id='update_btn'><i class='fa fa-save'></i> Save</button>
                </div>
            </div>
            <!-- /.box-header -->

            <div class="box-body">
                <form id='update_frm' action='update_salary'>
                    <div class="row">

                        <div class="col-lg-6">
                            <div class="form-group row">
                                <label for="" class="col-sm-4 col-form-label">Employee ID</label>
                                <input type='hidden' name='id' value='<?php echo $id; ?>' />
                                <div class="col-sm-8">
                                    <input type="text" id="emp_code" value="<?php echo $emp_code; ?>" class="form-control">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="example-text-input" class="col-sm-4 col-form-label">Select Employee</label>
                                <div class="col-sm-8">
                                    <select name="emp_id" id="emp_id" class="form-control">
                                        <?php dropdown_list('employee', 'id', 'e_name', $emp_id); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="example-text-input" class="col-sm-4 col-form-label">Select Month</label>
                                <div class="col-sm-8">
                                    <select name="month" id="month" required class="form-control ">
                                        <?php dropdown($month_list, $month); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="example-text-input" class="col-sm-4 col-form-label">Basic Salary</label>
                                <div class="col-sm-8">
                                    <input type="number" min="0" name="basic_salary" required class="form-control " value="<?php echo $basic_salary; ?>">
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="form-group row">
                                <label for="example-text-input" class="col-sm-4 col-form-label">Payable_amount</label>
                                <div class="col-sm-8">
                                    <input class="form-control" name="payable_amount" type="text" value='<?php echo $payable_amount; ?>'>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="example-text-input" class="col-sm-4 col-form-label">Payment Date</label>
                                <div class="col-sm-8">
                                    <input class="form-control " type="date" value='<?php echo date('Y-m-d', strtotime($payment_date)); ?>' name="payment_date">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="example-text-input" class="col-sm-4 col-form-label">Status </label>
                                <div class="col-sm-8">
                                    <select name='status' class='form-control ' required>
                                        <?php dropdown($status_list, $status); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.box-body -->
        </form>
    </section>
</div>
<!-- /.content-wrapper -->
<?php require_once('required/footer2.php'); ?>
<script>
    // function get_code(){
    //     $("#emp_id").change(funtion(){
    //         $id = $(this).
    //     })
    // }
</script>