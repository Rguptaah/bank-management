<?php require_once('required/header.php'); ?>
<?php require_once('required/menu.php');
$table = 'admit_card';
if (isset($_GET['link']) and $_GET['link'] != '') {
	$data = decode($_GET['link']);
	$id = $data['id'];
} else {
	$fee = insert_row($table);
	$id = $fee['id'];
}

if ($id != '') {
	$res = get_data($table, $id);
	if ($res['count'] > 0 and $res['status'] == 'success') {
		extract($res['data']);
	}
}
?>
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<h1> Generate Admit card </h1>
		<ol class="breadcrumb">
			<li class="breadcrumb-item"><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
			<li class="breadcrumb-item"><a href="#transport">Exam</a></li>
			<li class="breadcrumb-item active">Admit card</li>
		</ol>
	</section>
	<!-- Main content -->
	<section class="content">
		<!-- Basic Forms -->
		<div class="box box-default">
			<div class="box-header with-border">
				<h3 class="box-title">Generate Admit Card</h3>

				<div class="box-tools pull-right">
					<a href='manage_admit_card'><button type="button" class="btn btn-primary btn-sm"><i class="fa fa-table"></i>
						</button></a>
					<!--<button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>-->
				</div>
			</div>
			<div class="box-body">
				<form action='update_admit_card' method='post' id='update_frm'>
					<div class='row justify-content-center'>
						<div class='col-md-4'>

							<input type='hidden' value='<?php echo $id; ?>' name='id'>
							<div class="form-group">
								<label>Select Class </label>
								<select class="form-control" name='student_class' id="student_class" required>
									<?php dropdown($class_list, $student_class); ?>
								</select>
							</div>

							<div class="form-group">
								<label>Exam Name </label>
								<input class="form-control" type='text' name='exam_name' value='<?php echo $exam_name; ?>' required>
							</div>

							<div class="form-group">
								<label>In Time</label>
								<input class="form-control" type='time' placeholder='In Time' name='in_time' value='<?php echo $in_time; ?>' required>
							</div>
							<div class="form-group">
								<label>Exam Date</label>
								<input class="form-control" type='date' placeholder='Examination Date' name='exam_date' value='<?php echo $exam_date; ?>' required min="<?php echo date("Y-m-d"); ?>">
							</div>

						</div>
						<div class='col-md-6'>
							<div class="form-group">
								<label>Subject Name </label>
								<select name="subject" id="subject_list" class="form-control" required>
								</select>
							</div>

							<div class="form-group">
								<label>Timing</label>
								<input class="form-control" type='text' placeholder='10:00 AM -1:30 PM' name='timing' required value='<?php echo $timing; ?>'>
							</div>

							<div class="form-group">
								<label>Out Time</label>
								<input class="form-control" type='time' placeholder='Out Time' name='out_time' value='<?php echo $out_time; ?>' required>
							</div>

							<div class="form-group">
								<label>Status </label>
								<select name='status' class='form-control'>
									<?php dropdown($status_list, $status); ?>
								</select>
							</div>

				</form>
				<div class="form-group">

					<buttoon class="btn btn-orange btn-block " id='update_btn'> SAVE</buttoon>

				</div>

			</div>
		</div>
</div>
</div>
</section>
</div>
<?php require_once('required/footer.php'); ?>
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
<script>
	$("#task").on('change', function() {
		var task = $(this).children("option:selected").val();
		console.log(task);
		$("#reminder_frm").attr('action', task);

	});
	$('#summernote').summernote({
		placeholder: 'Enter Details',
		tabsize: 2,
		height: 150
	});

	//Automatic subject displayed on selecting class
	$("#student_class").on('change', function() {
		let str1 = $(this).val();
		// alert(str1);
		$.ajax({
			'type': "post",
			'url': 'required/master_process.php?task=select_class',
			'data': {
				'str': str1
			},
			success: function(data) {
				$("#subject_list").html(data);
			}

		})
	})
</script>


<!-- // const obj = {
		// 	hindi: $("#hindi").val(),
		// 	maths: $("#maths").val(),
		// 	science: $("#science").val(),
		// 	sst: $("#sst").val(),
		// 	english: $("#english").val(),
		// 	general_knowledge: $("#gk").val(),
		// 	infornmation_technology: $("#it").val(),
		// 	sanskrit_or_urdu: $("#san_or_urdu").val()
		// }
		// for (key in obj) {
		// 	let val =
		// 		str.includes(obj[key]);
		// 	if (val == "true") {
		// 		let text = toUpperCase(key);
		// 		$('#subject').append(new Option(text, text));
		// 	}
		// } -->